chrome.devtools.panels.create(
    'Capture',
    null,
    // "devtools_page.html",
    "index.html",
    function(panel){
    }
);