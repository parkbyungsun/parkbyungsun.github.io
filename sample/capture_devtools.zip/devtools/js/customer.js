// function get_source(document_body){
//     return document_body.innerText;
// }

// document.addEventListener('click', function(e){
//     chrome.extension.sendMessage({
//         action: "code",
//         source: e.toElement.innerText
//     });
// });


// console.log('abbbbbbbbbbbbbbbbbbbbbbbbbb');

// alert('customer.js');


